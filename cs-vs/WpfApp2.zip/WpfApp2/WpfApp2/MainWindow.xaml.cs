﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            //CanvasDemo();
            //StackPanelDemo();
            //WrapPanelDemo();
            //DockPanelDemo();
            //GridDemo();
        }

        private void CanvasDemo()
        {
            Canvas canv = new Canvas();

            //add the Canvas as sole child of Window
            this.Content = canv;
            canv.Margin = new Thickness(0, 0, 0, 0);
            canv.Background = new SolidColorBrush(Colors.White);

            //The Rectangle
            Rectangle r = new Rectangle();
            r.Fill = new SolidColorBrush(Colors.Blue);
            r.Stroke = new SolidColorBrush(Colors.Blue);
            r.Width = 145;
            r.Height = 126;
            r.SetValue(Canvas.LeftProperty, (double)124);
            r.SetValue(Canvas.TopProperty, (double)122);
            canv.Children.Add(r);

            //The Ellipse
            Ellipse el = new Ellipse();
            el.Fill = new SolidColorBrush(Colors.Green);
            el.Stroke = new SolidColorBrush(Colors.Green);
            el.Width = 121;
            el.Height = 100;
            //            el.SetValue(Canvas.ZIndexProperty, 1);
            el.SetValue(Panel.ZIndexProperty, 1);
            el.SetValue(Canvas.LeftProperty, (double)195);
            el.SetValue(Canvas.TopProperty, (double)191);
            canv.Children.Add(el);

            //The Ellipse
            Ellipse el1 = new Ellipse();
            el1.Fill = new SolidColorBrush(Colors.Red);
            el1.Stroke = new SolidColorBrush(Colors.Red);
            el1.Width = 131;
            el1.Height = 50;
            //el1.SetValue(Canvas.ZIndexProperty, 2);
            el1.SetValue(Panel.ZIndexProperty, 2);
            el1.SetValue(Canvas.LeftProperty, (double)210);
            el1.SetValue(Canvas.TopProperty, (double)211);
            canv.Children.Add(el1);

        }

        private void WrapPanelDemo()
        {
            WrapPanel wp = new WrapPanel();

            //add the WrapPanel as sole child of Window
            this.Content = wp;
            wp.Margin = new Thickness(0, 0, 0, 0);
            wp.Background = new SolidColorBrush(Colors.White);

            //Add Rectangles
            Rectangle r;
            for (int i = 0; i <= 10; i++)
            {
                r = new Rectangle();
                r.Fill = new SolidColorBrush(Colors.Blue);
                r.Margin = new Thickness(10, 10, 10, 10);
                r.Width = 60;
                r.Height = 60;
                wp.Children.Add(r);
            }
        }

        private void StackPanelDemo()
        {
            StackPanel sp = new StackPanel();

            //add the StackPanel as sole child of Window
            this.Content = sp;
            sp.Margin = new Thickness(10, 20, 30, 40);
            sp.Background = new SolidColorBrush(Colors.White);
            sp.Orientation = Orientation.Vertical;

            //Button1
            Button b1 = new Button();
            b1.Content = "Im Top of Stack";
            sp.Children.Add(b1);
            //Button2
            Button b2 = new Button();
            b2.Content = "Im Bottom of Stack";
            sp.Children.Add(b2);

            TextBlock Tb2 = new TextBlock();
            Tb2.Text = "Im TextBlock of Stack";
            sp.Children.Add(Tb2);

            TextBox Tbx2 = new TextBox();
            Tbx2.Text = "Im TextBox of Stack";
            sp.Children.Add(Tbx2);

        }

        private void DockPanelDemo()
        {
            DockPanel dp = new DockPanel();
            dp.LastChildFill = true;
            //this is the same as Width="Auto" in XAML, as long as 
            //its not applied  to a GridColumn Width/ Height / 
            //GridRow Width / Height which has special classes
            dp.Width = Double.NaN;
            dp.Height = Double.NaN;

            //add the WrapPanel as sole child of Window
            this.Content = dp;
            //Add Rectangles
            Rectangle rTop = new Rectangle();
            rTop.Fill = new SolidColorBrush(Colors.CornflowerBlue);
            rTop.Stroke = new SolidColorBrush(Colors.CornflowerBlue);
            rTop.Height = 20;
            dp.Children.Add(rTop);
            rTop.SetValue(DockPanel.DockProperty, Dock.Top);
            
            Rectangle rLeft = new Rectangle();
            rLeft.Fill = new SolidColorBrush(Colors.Aqua);
            rLeft.Stroke=new SolidColorBrush(Colors.Beige);
            rLeft.Width = 40;
            dp.Children.Add(rLeft);
            rLeft.SetValue(DockPanel.DockProperty, Dock.Left);

            Rectangle rFill = new Rectangle();
            rFill.Fill = new SolidColorBrush(Colors.Orange);
            rFill.Stroke = new SolidColorBrush(Colors.Orange);
            dp.Children.Add(rFill);

        }

        private void GridDemo()
        {
            Grid grid = new Grid();
            grid.Width = Double.NaN;
            //this is the same as Width="Auto" in XAML

            //this is the same as Height="Auto" in XAML
            grid.Height = Double.NaN;
            //add the Grid as sole child of Window
            this.Content = grid;

            //col1

            ColumnDefinition cd1 = new ColumnDefinition();
            cd1.Width = new GridLength(40);
            grid.ColumnDefinitions.Add(cd1);
            //col2
            ColumnDefinition cd2 = new ColumnDefinition();
            cd2.Width = new GridLength(1, GridUnitType.Star);
            grid.ColumnDefinitions.Add(cd2);

            //col3
            ColumnDefinition cd3 = new ColumnDefinition();
            cd3.Width = new GridLength(2, GridUnitType.Star);
            grid.ColumnDefinitions.Add(cd3);
            //Now add the cells to the grid
            Rectangle r1c1 = new Rectangle();
            r1c1.Fill = new SolidColorBrush(Colors.Aqua);
            r1c1.SetValue(Grid.ColumnProperty, 0);
            r1c1.SetValue(Grid.RowProperty, 0);
            grid.Children.Add(r1c1);

            Rectangle r1c23 = new Rectangle();
            r1c23.Fill = new SolidColorBrush(Colors.Plum);
            r1c23.SetValue(Grid.ColumnProperty, 1);
            r1c23.SetValue(Grid.ColumnSpanProperty, 2);
            grid.Children.Add(r1c23);
        }

        private void PutItAllTogether()
        {
            //no code
        }
        private void txtBlkName_KeyDown(object sender, KeyEventArgs e)
        {
           
        }
    }
}
